import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;

public class testCase2 {
    public static void main(String[] args) {
        double i=8630.29;

    }
}
