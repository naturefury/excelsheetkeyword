package projectconstants;

public final class MenuItem {

    public static String MyCard(){
        return "My Card";
    }
    public static String CardTransfer(){
        return "Card transfer";
    }
    public static String CurrencyConverter(){
        return "Currency Converter";
    }
    public static String Beneficiaries(){
        return "Beneficiaries";
    }
    public static String Settings(){
        return "Settings";
    }
    public static String LoadPartners(){
        return "Load Partners";
    }
    public static String DistributionPartners() {
        return "Distribution Partners";
    }
    public static String More(){
        return "More";
    }
}
