package constants;

public interface Keys {

    final String RunID="RunID";
    final String OS="DeviceOS";
    final String RunFolder="RunFolder";
    final String Device="DeviceName";
    final String ObjectRepository="objectRepositoryFile";
}
