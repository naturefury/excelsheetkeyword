package constants;

public interface Device {
	String TGSMOB2131 = "TGSMOB2131"; // Galaxy J7
	String TGSMOB2128 = "TGSMOB2128"; // Galaxy J7
	String TGSMOB2126 = "TGSMOB2126"; // IPhone X Silver
	String TGSMOB2124 = "TGSMOB2124"; // IPad Silver
	String ONEPLUS3 = "OnePlus3"; 	  //OnePlus 3
}
