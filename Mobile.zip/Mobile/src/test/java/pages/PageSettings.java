package pages;

import base.Keywords;
import base.Test;
import com.cucumber.listener.Reporter;
import constants.Keys;
import constants.OS;
import exceptions.ApplicationException;
import org.junit.Assert;
import xpath.Matching;

import java.text.ParseException;

public class PageSettings extends Keywords {

    private String keySettingsPageTitle="Getgo.Settings.LblTitle";
    private String keyPasswordOption="Getgo.Settings.LblPassword";


    public void verifyPageTitle(String ititle) throws ApplicationException {
        verify.elementTextMatching(xpathOf.textView(Matching.text("Settings")),ititle);
    }

    public void clickPasswordOption() throws ApplicationException {
        click.elementBy(xpathOf.textView(Matching.text("Password")));
    }

}