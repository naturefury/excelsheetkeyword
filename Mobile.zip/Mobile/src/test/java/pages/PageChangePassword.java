package pages;

import base.Keywords;
import com.cucumber.listener.Reporter;
import exceptions.ApplicationException;
import xpath.Matching;

import java.text.DecimalFormat;

    public class PageChangePassword extends Keywords {

        private String keyLblPageTitle = "Getgo.UpdatePassword.LblTitle";
        private String keyTxtBoxOldPwd = "Getgo.UpdatePassword.TxtOldpassword";
        private String keyTxtBoxNewPwd = "Getgo.UpdatePassword.TxtNewpassword";
        private String keyTxtBoxConfirmNewPwd = "Getgo.UpdatePassword.TxtConfirmpassword";
        private String keyBtnSubmit = "Getgo.UpdatePassword.BtnSubmit";
        private String keyLblSuccessPopUpTitle = "Getgo.UpdatePassword.LblSuccesspopuptilte";
        private String keyBtnSuccessPopUpOK = "Getgo.UpdatePassword.BtnSuccesspopupOK";

        public void verifyPageTitle(String ititle) throws ApplicationException {
            verify.elementTextContains(xpathOf.textView(Matching.youDecide("Update Password")), ititle);
        }

        public void enterPwdDetails(String oldpwd, String newpwd, String confirmpwd) throws ApplicationException {
            type.data(xpathOf.textView(Matching.text("Enter Old password")), oldpwd);
            type.data(xpathOf.textView(Matching.text("Enter New password")), newpwd);
            type.data(xpathOf.textView(Matching.text("Confirm New password")), confirmpwd);

        }

        public void clickSubmitBtn() throws ApplicationException {
            click.elementBy(xpathOf.textView(Matching.text("SUBMIT")));

        }

        public void verifyPasswordIsSuccessfull(String ititle) throws ApplicationException {
            verify.elementTextMatching(keyLblSuccessPopUpTitle,ititle);

        }
        public void closePopUp() throws ApplicationException {
            click.elementBy(keyBtnSuccessPopUpOK);

        }

    }


