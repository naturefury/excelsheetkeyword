package Trash;

public class Sample {
	
	public static void main(String[] args) {
		
		String test="name";
		
		switch (test) {
		case "adddress":
		case "id":	
		case "name":	
			System.out.println("logic hereeeee");
			break;
		case "pincode":			
			break;
		case "alternate":			
			break;
		default:
			break;
		}
		
	}

}
